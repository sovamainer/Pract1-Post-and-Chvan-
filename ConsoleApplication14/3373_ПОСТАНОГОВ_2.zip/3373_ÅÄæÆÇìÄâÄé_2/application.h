#ifndef APPLICATION_H
#define APPLICATION_H
#include "array.h"

class TApplication
{
public:
    TApplication();
    int exec();

private:
    int menu();
};

#endif // APPLICATION_H
