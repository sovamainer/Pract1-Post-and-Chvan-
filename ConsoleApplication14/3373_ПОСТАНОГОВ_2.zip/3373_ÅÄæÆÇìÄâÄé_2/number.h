#ifndef NUMBER_H
#define NUMBER_H
#include "complex.h"

typedef TComplex number;

#endif // NUMBER_H