﻿#include <iostream>
#include "application.h"

using namespace std;

int main()
{
    setlocale(LC_ALL, "RU");
    TApplication app;
    app.exec();
}
